﻿Public Class FrmIndividual1

    'Declared and Initialized variables as global
    Dim Merch As String = ""

    Dim TempAmt As String = ""
    Dim Amount As Double = 0
    Dim TranDate As String = ""
    Dim Record As String = ""
    Dim Total As Double = 0

    Dim Check As Boolean = False


    Private Sub FrmIndividual1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    'the button click works as a loop


    Private Sub BtnTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnTransaction.Click

        



        'setting string references equal to textboxes

        If (IsNumeric(TxtMerchant.Text())) Then   'used IsNumeric method to test if a number is present in textBox
            MessageBox.Show("Opps, you entered a number") 'MessageBox displays error and program Ends
            End

        Else : Merch = TxtMerchant.Text()

        End If



        If (IsNumeric(TxtAmount.Text())) Then

            TempAmt = TxtAmount.Text()

        Else : MessageBox.Show("Opps, you entered a letter") 'MessageBox displays error and program Ends
            End

        End If




        Amount = CDbl(TempAmt)


        While (Check = False)  'Will be repeated until user correctly enters date


            If ((TxtDate.Text()).Contains("/")) Then  'string method "Contains" checks for "/"

                TranDate = TxtDate.Text() 'String referenced to TextBox
                Check = True

            Else
                : MessageBox.Show("Please Enter date as such: xx/xx/xx") 'MessageBox displays error and program Ends

                End   'can't get my while loop to work right

            End If


        End While








        'Creating Record (which is a giant string)
        Record = TranDate & "       " & Merch & "        " & "$ " &TempAmt & vbCrLf




        'total calculation
        Total = (Amount + Total)






        'Clearing textboxes
        TxtMerchant.Clear()
        TxtAmount.Clear()
        TxtDate.Clear()

        'Using the AppendText method to add to my TextBox
        'I still need to find a way to vertically align
        'Ok got it.  Add code "& vbCrLf" to end line 
        TxtTransactions.AppendText(Record)


        TxtTotal.Text = CStr(Total) 'Converted to string





    End Sub
End Class
