﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmIndividual1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtMerchant = New System.Windows.Forms.TextBox()
        Me.TxtDate = New System.Windows.Forms.TextBox()
        Me.TxtAmount = New System.Windows.Forms.TextBox()
        Me.TxtTransactions = New System.Windows.Forms.TextBox()
        Me.TxtTotal = New System.Windows.Forms.TextBox()
        Me.LblMerchant = New System.Windows.Forms.Label()
        Me.LblTotal = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LblDate = New System.Windows.Forms.Label()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.BtnTransaction = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'TxtMerchant
        '
        Me.TxtMerchant.Location = New System.Drawing.Point(139, 59)
        Me.TxtMerchant.Name = "TxtMerchant"
        Me.TxtMerchant.Size = New System.Drawing.Size(222, 22)
        Me.TxtMerchant.TabIndex = 0
        '
        'TxtDate
        '
        Me.TxtDate.Location = New System.Drawing.Point(726, 59)
        Me.TxtDate.Name = "TxtDate"
        Me.TxtDate.Size = New System.Drawing.Size(130, 22)
        Me.TxtDate.TabIndex = 1
        '
        'TxtAmount
        '
        Me.TxtAmount.Location = New System.Drawing.Point(479, 59)
        Me.TxtAmount.Name = "TxtAmount"
        Me.TxtAmount.Size = New System.Drawing.Size(113, 22)
        Me.TxtAmount.TabIndex = 2
        '
        'TxtTransactions
        '
        Me.TxtTransactions.Location = New System.Drawing.Point(139, 184)
        Me.TxtTransactions.Multiline = True
        Me.TxtTransactions.Name = "TxtTransactions"
        Me.TxtTransactions.ReadOnly = True
        Me.TxtTransactions.Size = New System.Drawing.Size(717, 266)
        Me.TxtTransactions.TabIndex = 3
        '
        'TxtTotal
        '
        Me.TxtTotal.Location = New System.Drawing.Point(408, 501)
        Me.TxtTotal.Name = "TxtTotal"
        Me.TxtTotal.ReadOnly = True
        Me.TxtTotal.Size = New System.Drawing.Size(100, 22)
        Me.TxtTotal.TabIndex = 4
        '
        'LblMerchant
        '
        Me.LblMerchant.AutoSize = True
        Me.LblMerchant.Location = New System.Drawing.Point(52, 59)
        Me.LblMerchant.Name = "LblMerchant"
        Me.LblMerchant.Size = New System.Drawing.Size(67, 17)
        Me.LblMerchant.TabIndex = 5
        Me.LblMerchant.Text = "Merchant"
        '
        'LblTotal
        '
        Me.LblTotal.AutoSize = True
        Me.LblTotal.Location = New System.Drawing.Point(296, 504)
        Me.LblTotal.Name = "LblTotal"
        Me.LblTotal.Size = New System.Drawing.Size(92, 17)
        Me.LblTotal.TabIndex = 7
        Me.LblTotal.Text = "Total Amount"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(405, 59)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 17)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Amount $"
        '
        'LblDate
        '
        Me.LblDate.AutoSize = True
        Me.LblDate.Location = New System.Drawing.Point(682, 62)
        Me.LblDate.Name = "LblDate"
        Me.LblDate.Size = New System.Drawing.Size(38, 17)
        Me.LblDate.TabIndex = 9
        Me.LblDate.Text = "Date"
        '
        'BtnTransaction
        '
        Me.BtnTransaction.Location = New System.Drawing.Point(326, 119)
        Me.BtnTransaction.Name = "BtnTransaction"
        Me.BtnTransaction.Size = New System.Drawing.Size(305, 37)
        Me.BtnTransaction.TabIndex = 10
        Me.BtnTransaction.Text = "Record Transaction"
        Me.BtnTransaction.UseVisualStyleBackColor = True
        '
        'FrmIndividual1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(902, 575)
        Me.Controls.Add(Me.BtnTransaction)
        Me.Controls.Add(Me.LblDate)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LblTotal)
        Me.Controls.Add(Me.LblMerchant)
        Me.Controls.Add(Me.TxtTotal)
        Me.Controls.Add(Me.TxtTransactions)
        Me.Controls.Add(Me.TxtAmount)
        Me.Controls.Add(Me.TxtDate)
        Me.Controls.Add(Me.TxtMerchant)
        Me.Name = "FrmIndividual1"
        Me.Text = "Credit Card Transaction"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtMerchant As System.Windows.Forms.TextBox
    Friend WithEvents TxtDate As System.Windows.Forms.TextBox
    Friend WithEvents TxtAmount As System.Windows.Forms.TextBox
    Friend WithEvents TxtTransactions As System.Windows.Forms.TextBox
    Friend WithEvents TxtTotal As System.Windows.Forms.TextBox
    Friend WithEvents LblMerchant As System.Windows.Forms.Label
    Friend WithEvents LblTotal As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LblDate As System.Windows.Forms.Label
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents BtnTransaction As System.Windows.Forms.Button

End Class
