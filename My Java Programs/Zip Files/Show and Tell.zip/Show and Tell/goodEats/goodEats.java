/**
   This program creates an instance of the BrienzBistro class
   which show a GUI of Brienz Bistro
*/


public class goodEats
{
   public static void main(String[] args)
   {
      new BrienzBistro();
   }
	
}//class