/**
   This program creates an instance of the BrienzBistro class
   which show a GUI of Brienz Bistro
*/


public class TestGUI
{
   public static void main(String[] args)
   {
      new BoneAceGUI();
   }
	
}//class