import java.awt.GridLayout;
import java.awt.Container;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;


public class myProg { 



   

  /** Main method */
  public static void main(String[] args) {
    
	 


	     //create a window, set resolution, and color
	 	JFrame Win1 = new JFrame();
	 	Win1.setBackground(Color.GREEN);
	   Win1.setSize(1024,768);
	  
	     //create a panel
	 	JPanel Panel1 = new JPanel();
	    Panel1.setPreferredSize(new Dimension(700, 600));
		 
	   JPanel Panel2 = new JPanel();
	    Panel2.setPreferredSize(new Dimension(100, 75));
	  
 
	    // Create a BorderLayout manager for 1 Window and 2 panels
      Win1.setLayout(new BorderLayout(5,5));	 
      
		Panel1.setLayout(new BorderLayout(5,5));
		
		Panel2.setLayout(new BorderLayout(5,5));
		  	 		 
	 
      	//creating frames 
		 bevPanel frame1 = new bevPanel("Full-Turpentine","Decaf-Turpentine","Beverages"); 
			
	  	 dessertPanel frame2 = new dessertPanel("Cotton-ball Cake","Mushroom Cake", "Desserts"); 
		  
		  
		 //   frame3 = new EntreePanel("Sock Sandwich","Spring Salad","Spider Soup","Gym-Mat Sausage","bolts and cheese","Entrees");
		  
		 EntreePanel frame3 = new EntreePanel("Sock Sandwich","Spring Salad","Spider Soup","Gym-Mat Sausage","bolts and cheese","Entrees");
		   
		   		 		
		 twoButtonPanel frame4 = new twoButtonPanel("Total","Exit");
				
		 JLabel label = new JLabel("           "+"Welcome to Brian's Bistro. Let's Eat!"); //create a label
	
		 
		 double EntreeCost =0.0;
			
		 Panel2.add(new JTextField("Total:"+EntreeCost),BorderLayout.CENTER);
    

	
	    //Add the components to the content pane of Panel1.  //everything must be put into a content pane.
      Panel1.add(frame1, BorderLayout.WEST);
      
		Panel1.add(frame2, BorderLayout.EAST);
		
		Panel1.add(frame3, BorderLayout.CENTER);
		
		Panel1.add(frame4, BorderLayout.SOUTH);
   	  		
		Panel2.add(label,  BorderLayout.WEST);
		   label.setPreferredSize(new Dimension(250,50));  //set size of label

	    
		Panel2.add(new JTextField("Total:"),BorderLayout.CENTER);
		      				

		  //add colors to panels
		frame1.setBackground(Color.CYAN);
		frame2.setBackground(Color.MAGENTA);
		frame3.setBackground(Color.LIGHT_GRAY);

	  
	    //make both panels visible
      Panel1.setVisible(true);
	   Panel2.setVisible(true);  
	 
	 
	    //adding panels to Window 
		 Win1.add(Panel1,BorderLayout.CENTER);
			
		 Win1.add(Panel2,BorderLayout.NORTH);
			
		 
			   //Window parameters
			 Win1.setTitle("Brienz Bistro");
		      //closes program when window is closed
		  	 Win1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		  	 Win1.setVisible(true);
		
			
	    //  double EntreeCost;
			 
		   EntreeCost = frame3.getEntreeTotal(); 
			
			
			Panel2.add(new JTextField("Total:"+EntreeCost),BorderLayout.CENTER);
			
			 
  	}//main






   /**
      Private inner class that handles the event when
      the user clicks the Exit button.
   */

   private class ExitButtonListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
          System.exit(0);
      }
   }//close exitlistener


  




}//main public class






