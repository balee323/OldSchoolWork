import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/**
   The BagelPanel class allows the user to select either
   a white or whole wheat bagel.
*/

public class bevPanel extends JPanel
{
   // The following constants are used to indicate
   // the cost of each type of foods.
	
	//probably wont use this
	
  // public final double WHITE_BAGEL = 1.25;
 //   public final double WHEAT_BAGEL = 1.50;


    



	
	private JButton button3;
	private JButton button4;  
	private ButtonGroup bg;           // Radio button group
  
 /*

	private String foodItem1;
	private String foodItem2;


   public void setGenPanel(String food1, String food2){
			  
			  foodItem1 = food1;
			  foodItem2 = food2;
			  
			 }//set panel

  */
  
 
   public bevPanel(String foodItem1,String foodItem2,String category)
   {
	
	
	    
		JPanel panel = new JPanel(); 
	    
		 
		 ImageIcon image1 = new ImageIcon("image/turp1.jpg");
		 
		 button3 = new JButton(foodItem1, image1);
		 button4 = new JButton(foodItem2, image1);
	

      // Create a GridLayout manager with 
      // two rows and one column.

     // setLayout(new BorderLayout(5,5));
      setLayout(new GridLayout(2, 1)); 

      // Group the radio buttons.
      bg = new ButtonGroup();
     // bg.add(button1);
     // bg.add(button2);
		bg.add(button3);
		bg.add(button4);

      // Add a border around the panel.
      setBorder(BorderFactory.createTitledBorder(category));

      	// Add the radio buttons to the panel.
      	   add(button3);   
	         add(button4);

	}//constructor
	

  

   /**
      getBagelCost method
      @return The cost of the selected bagel.
   */
 
 
 
 
   /* not sure if I am using this 
	 
   public double getBagelCost()
   {
      double bagelCost = 0.0;

      if (whiteBagel.isSelected())
         bagelCost = WHITE_BAGEL;
      else
         bagelCost = WHEAT_BAGEL;

      return bagelCost;
   }

  
  */


  
	 //gPanel.setVisible(true);




}


