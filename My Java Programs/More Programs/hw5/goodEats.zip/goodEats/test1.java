import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.GridLayout;
import java.awt.Container;
import javax.swing.*;
import java.awt.*;


public class test1 { 
 
  /** Main method */
  public static void main(String[] args) {
    
	 
	  
	 BrienzPanel frame = new BrienzPanel();

	// BorderFactory frame2 = new BorderFactory();
	 
	//frame2.createTitleBorder("Brienz Food");
	 
	 
   frame.setTitle("Brienz Food");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(1024, 768);
    frame.setVisible(true);
  }
}